<?php

return [
    \Invo\Providers\ConfigProvider::class,
    \Invo\Providers\DatabaseProvider::class,
    \Invo\Providers\DispatcherProvider::class,
    \Invo\Providers\FlashProvider::class,
    \Invo\Providers\SessionProvider::class,
    \Invo\Providers\SessionBagProvider::class,
    \Invo\Providers\UrlProvider::class,
    \Invo\Providers\ViewProvider::class,
    \Invo\Providers\VoltProvider::class,
];
